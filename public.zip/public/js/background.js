//http://compressjpeg.com/ 


$(document).ready(function() {

images = []; 


$.ajaxSetup({
headers: {
'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')


}
});                    

$.post('/GetImages', function(data) {
 
	list  = $.parseJSON(data);
 
 for (var i = 0; i < list.length; i++) {

 	  images.push(list[i]);

 	  console.log(list[i]);
 	
 }

  changeImages();
});






function changeImages(){




    rand = Math.floor(Math.random() * images.length); 


	 $('#bg').fadeTo('slow', 0.3, function()
	 {

      $(this).css("background-image", "url("+images[rand]+")")

	 }).fadeTo('slow', 1);




}

setInterval(function(){ 

  changeImages();

}, 60000);


});