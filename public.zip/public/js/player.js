// JavaScript Document
// update 2.0


$(document).ready( function() {

$("#carousel").carousel();

playerInstance = jwplayer("radio");

jwplayer.key = "y5J6LSVMPE4KtTFykuCDgvvwgPeDRpiiUnfRsA=="
// jw player API key 
playerInstance.setup({
   // link to vocast server 
  flashplayer: "jwplayer.flash.swf",
    file: "http://s6.voscast.com:9368/;stream.mp3",
    flashvars: 'ignoremeta=true',
  autostart: true,
  image:"images/logo.png"
  
});
  
});




/// url and command 
//http://webservices.amazon.com/scratchpad/index.html#http://webservices.amazon.com/onca/xml?Service=AWSECommerceService&Operation=ItemSearch&SubscriptionId=AKIAIIFFJYWIGQWQVYMQ&AssociateTag=livstu09-20 &SearchIndex=Music&Keywords=chronixx&ResponseGroup=Images,Offers
// https://en.wikipedia.org/w/api.php?format=xml&action=query&prop=extracts&explaintext=&titles=chronixx
// C:\Users\SeanDp32>start chrome.exe --user-data-dir="C:/Chrome dev session" --disable-web-security




