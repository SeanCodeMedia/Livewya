

<div id = "footer">


   <div class="row">
           
           <div class="col-md-1">
           	  
               <a href="https://www.instagram.com/livewya95.7/"><img src="images/instagram.png" width="40px" height="40px"></a>
           </div>

            <div class="col-md-1">
           	  
           	     <a href="https://www.youtube.com/channel/UCd-sdbnIn3NQshYZdYvovUg"><img src="images/youtube.png" width="40px" height="40px"></a>

           </div>

            <div class="col-md-1">
           	  
           	     <a href="https://www.facebook.com/livewya95.7/"><img src="images/facebook.png" width="40px" height="40px"></a>

           </div>


   </div> 


<div id="flags">
    
    </div>
  

</div> 