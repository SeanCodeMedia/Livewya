@extends("layouts.masterLayout")

@include("includes.navBar")

<?php $title = "LiveWya|BookParty"?> 


<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>

<link rel="stylesheet" href="css/BookParty.css'">
<script type="text/javascript" src="public/js/shopingCart.js"></script>

@section("container")

<style type="text/css">
	body{
		background-color:#FFB94E;
	}
</style>

<!--
<div  class="row container ">
<div id="panel2" class="animated slideInRight panel panel-default">
  <div class="panel-heading">
    <h3 class="panel-title"><strong>Cost of Party</strong></h3>
  </div>
  <div id = "shopCart" class="panel-body">
      
     
     <p id = "total"><strong>Total</strong></p>

     <form action="" method="POST">
                
                <p>
                    <script src="https://checkout.stripe.com/checkout.js" class="stripe-button"
                       data-key="{{-- env('STRIPE_KEY') --}}"
                       data-amount="45000"
                       data-name="Stripe.com"
                       data-description="Widget"
                       data-locale="auto"
                       data-currency="usd">
                     </script>
                </p>  
</form>
 </div>
</div>
</div>
-->
<div  class=" row container">
<div class = "col-md-8 col-md-offset-2">
<div id="panel" class="panel panel-default animated bounceInUp">
  <div class="panel-heading">
    <h3 class="panel-title"><strong>Book Livewya</strong></h3>
  </div>
  <div class="panel-body">
       <form role="form" method="POST" action="/Payment">
        {{ csrf_field() }}

        <div class="form-group {{ $errors->has('date') ? ' animated shake has-error' : '' }}">
           <label for="">Date of party </label>
  <input type="date" class="form-control" name="date" id="dateBox" value="{{$date}}" placeholder="date">
  
   @if ($errors->has('name'))
                <span class="help-block">
                    <strong>{{ $errors->first('name') }}</strong>
                </span>
     @endif 
         </div>


        <div class="form-group {{ $errors->has('name') ? ' animated shake has-error' : '' }}">
           <label for="">Name</label>
  <input type="text" class="form-control" name="name" id="nameBox" value="{{Auth::user()->name}}" placeholder="name">


   @if ($errors->has('name'))
                <span class="help-block">
                    <strong>{{ $errors->first('name') }}</strong>
                </span>
     @endif 
         </div>

     <div class="form-group {{ $errors->has('email') ? ' animated shake has-error' : '' }}" >
           <label for="">Email</label>
         <input type="Email" class="form-control" name= "email" id="EmailBox" value="{{Auth::user()->email}}" placeholder="name">

                    @if ($errors->has('email'))
                <span class="help-block">
                    <strong>{{ $errors->first('email') }}</strong>
                </span>
            @endif 
         </div>


         <div   class="form-group {{ $errors->has('address') ? ' animated shake has-error' : '' }}">
           <label for="">Address</label>
         <input type="text" name="address" class="form-control" id="AddressBox" placeholder="Address" value="{{ old('address') }}">

            @if ($errors->has('address'))
                <span class="help-block">
                    <strong>{{ $errors->first('address') }}</strong>
                </span>
            @endif 

         </div>
      
 		 <div  class="form-group {{ $errors->has('city') ? ' animated shake has-error' : '' }}">
           <label for="">City</label>
 <input type="text" name="city" class="form-control" value="{{ old('city') }}" id= "CityBox" placeholder="City">
                
                 @if ($errors->has('city'))
                <span class="help-block">
                    <strong>{{ $errors->first('city') }}</strong>
                </span>
            @endif 
         </div>

         <div class="form-group {{ $errors->has('state') ? ' animated shake has-error' : '' }}">
           <label for="">State</label>
         <select name="state"  class="form-control" value="{{ old('state') }}">
  <option value="">Please Select A State</option>      
  <option value="AL">Alabama</option>
  <option value="AK">Alaska</option>
  <option value="AZ">Arizona</option>
  <option value="AR">Arkansas</option>
  <option value="CA">California</option>
  <option value="CO">Colorado</option>
  <option value="CT">Connecticut</option>
  <option value="DE">Delaware</option>
  <option value="DC">District Of Columbia</option>
  <option value="FL">Florida</option>
  <option value="GA">Georgia</option>
  <option value="HI">Hawaii</option>
  <option value="ID">Idaho</option>
  <option value="IL">Illinois</option>
  <option value="IN">Indiana</option>
  <option value="IA">Iowa</option>
  <option value="KS">Kansas</option>
  <option value="KY">Kentucky</option>
  <option value="LA">Louisiana</option>
  <option value="ME">Maine</option>
  <option value="MD">Maryland</option>
  <option value="MA">Massachusetts</option>
  <option value="MI">Michigan</option>
  <option value="MN">Minnesota</option>
  <option value="MS">Mississippi</option>
  <option value="MO">Missouri</option>
  <option value="MT">Montana</option>
  <option value="NE">Nebraska</option>
  <option value="NV">Nevada</option>
  <option value="NH">New Hampshire</option>
  <option value="NJ">New Jersey</option>
  <option value="NM">New Mexico</option>
  <option value="NY">New York</option>
  <option value="NC">North Carolina</option>
  <option value="ND">North Dakota</option>
  <option value="OH">Ohio</option>
  <option value="OK">Oklahoma</option>
  <option value="OR">Oregon</option>
  <option value="PA">Pennsylvania</option>
  <option value="RI">Rhode Island</option>
  <option value="SC">South Carolina</option>
  <option value="SD">South Dakota</option>
  <option value="TN">Tennessee</option>
  <option value="TX">Texas</option>
  <option value="UT">Utah</option>
  <option value="VT">Vermont</option>
  <option value="VA">Virginia</option>
  <option value="WA">Washington</option>
  <option value="WV">West Virginia</option>
  <option value="WI">Wisconsin</option>
  <option value="WY">Wyoming</option>
</select>       
        @if ($errors->has('state'))
                <span class="help-block">
                    <strong>{{ $errors->first('state') }}</strong>
                </span>
            @endif 
         </div>

      <div class="form-group {{ $errors->has('zipCode') ? ' animated shake has-error' : '' }}">
           <label for="">Zip Code</label>
         <input type="text" name="zipCode" class="form-control" id="ZipCodeBox" placeholder="ZipCode" value="{{ old('zipCode') }}" >
        
            @if ($errors->has('zipCode'))
                <span class="help-block">
                    <strong>{{ $errors->first('zipCode') }}</strong>
                </span>
            @endif 

         </div>

        <div class="form-group {{ $errors->has('phoneNumber') ? ' animated shake has-error' : '' }}">
           <label for="">Phone Number</label>
    <input type="text" name="phoneNumber" class="form-control" id="phoneNumber" placeholder="(000)-000-0000" value="{{ old('phoneNumber') }}" >
        
            @if ($errors->has('phoneNumber'))
                <span class="help-block">
                    <strong>{{ $errors->first('phoneNumber') }}</strong>
                </span>
            @endif 

         </div>


<div class="form-group {{ $errors->has('state') ? ' animated shake has-error' : '' }}">
<label for="">Phone Carrier</label><br>
<strong><small style="color:red;">*Please note if carrier is incorrect livewya will not be able to <br> send you text messages to virify party</small></strong>
<select name="Carrier"  class="form-control" value="{{ old('Carrier') }}">
  <option value="">Please Select A Phone Carrier</option>      
  <option value="att">AT&amp;T</option>
  <option value="airfiremobile">Air Fire Mobile</option>
  <option value="alaskacommunicates">Alaska Communicates</option>
  <option value="ameritech">Ameritech</option>
  <option value=" moostmobile">Boost Mobile</option>
  <option value="cleartalk">Clear Talk</option>
  <option value="cricket">Cricket</option>
  <option value="metropcs">Metro PCS</option>
  <option value="nextech">NexTech</option>
  <option value="projectfi"> Project Fi</option>
  <option value="unicel">Unicel</option>
  <option value="verizonwireless">Verizon Wireless</option>
  <option value="virginmobile">Virgin Mobile</option>
  <option value="tmobile">T-Mobile</option>
  <option value="sprint">Sprint</option>
  <option value="uscellular"> US Cellular</option>
  <option value="null">Other</option>
</select>       


        <div class="form-group {{ $errors->has('StartTime') ? ' animated shake has-error' : '' }}">
           <label for="">What time does your party start?</label>
         <input type="time" name ="StartTime" class="form-control" id="time1" placeholder="Start time" value="{{ old('StartTime') }}" >

                     @if ($errors->has('StartTime'))
                <span class="help-block">
                    <strong>{{ $errors->first('StartTime') }}</strong>
                </span>
            @endif 

         </div>

   		<div class="form-group {{ $errors->has('EndTime') ? ' animated shake has-error' : '' }}">
           <label for="">What time does your party end?</label>
         <input type="time" name="EndTime" class="form-control" id="time2" placeholder="End time" value="{{ old('EndTime') }}">

                     @if ($errors->has('EndTime'))
                <span class="help-block">
                    <strong>{{ $errors->first('EndTime') }}</strong>
                </span>
            @endif 

         </div>
			
			<div class="form-group {{ $errors->has('Number') ? ' animated shake has-error' : '' }}">
           <label for="">How many people do you expect ?</label>
         <input type="number" name="Number" class="form-control" id="number" placeholder="Number of people " value="{{ old('Howmany') }}">

          
          @if ($errors->has('Number'))
                <span class="help-block">
                    <strong>{{ $errors->first('Number') }}</strong>
                </span>
            @endif 


         </div>

         	{{-- <div class="form-group">
           <label for="">Do you want your party to be videoed ? </label>
           <br>
         <input type="checkbox" id ="videos" onclick="check2()"> Cost to video party is $50 
         </div>

         <div class="form-group">
           <label for="">Do you want us to take photos at your party ? </label>
           <br>
         <input type="checkbox" id ="photos" onclick="check()"> Cost to take photos at party is $50 
         </div> --}}

         	<div class="form-group">
           <label for="">Additional Information</label>
                   
                   <textarea rows="10" cols="60"  placeholder="Tell us more about your party"></textarea>

         </div>
          
       
       
          <div class="form-group">
          	  <button type="submit" class="btn btn-primary">
                            Book Party 
              </button>
           </div>
 
     </form>

@stop