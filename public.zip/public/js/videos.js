
$(document).ready(function() {
	


setInterval(function () {
    
    console.log("fade")

	$("#fade").removeClass('animated fadeIn');

	$("#fade").addClass('animated fadeOut');


},2000)

setInterval(function () {

	console.log("fade2")

    $("#fade").removeClass('animated fadeOut');
    
	$("#fade").addClass('animated fadeIn');

},4000)

});