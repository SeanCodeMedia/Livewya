<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class backgroundImages extends Model
{
    public $table = "BackgroundImages";
}
