@extends("layouts.masterLayout")

@include("includes.navBar")

<?php $title = "LiveWya|AdminDashBoard"?> 


@section('container')

<style type="text/css">
    body{background-color:#19B5FE;}
</style>

<link rel="stylesheet" type="text/css" href="css/admin.css">

<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>

<script type="text/javascript"  src="js/admin.js"></script>

<div class="container webcontainer">
<center><h1 id="welcome"> Hello, {{Auth::user()->name}}</h1></center>


<div class="row">

   <div class="col-md-4">
<center>
<div id="currentListner" class="panel panel-default">
  <div class="panel-heading"><strong>Current Number Of Listeners</strong> </div>
  <div class="panel-body">
    
    <!--VosCast.com SHOUTcast Server Stats-->
<strong>
<center><div id="listenersNum" ><script type="text/javascript" src="http://cdn.voscast.com/stats/display.js?key=43d74fd92029036fddf021f4e6606167&stats=currentlisteners"></script>
</div></center>
</strong>
<!--End SHOUTcast Server Stats-->

         </div>
    </div>
  </div>
</center>
        <div class="col-md-4">

            <div class="panel panel-default">
                <div class="panel-heading">AdminDashboard</div>

                <div class="panel-body">
                    You are logged in!
                </div>
            

            </div>
        </div>


     <div class="col-md-4">
    
 <center>   <button type="button" id ="autoDJ" class="btn btn-primary btn-lg">
    </button></center>

</div>

    </div>


    <div class="row">

 <div  class="col-md-4">  
        <center>
         <div id = "edit" class="well">

            @if(session()->has('successMessage'))
              <div class="alert alert-success">
                  {{ session()->get('successMessage') }}
            </div>
           @endif

            <ul id="sortable">

           @foreach($images as $key=>$image)
        
   <li id="{{$key}}" class="ui-state-default"><span class="ui-icon ui-icon-arrowthick-2-n-s"></span>
    
     <form  method="POST" action="/Delete">
        <div class="form-group">
             <input type="hidden" name="ImageID" value="{{$image->id}}">
             <input type="hidden" name="ImageName" value="{{$image->images}}">
             <input class="btn btn-danger" type="submit" value="Delete" name="submit">
             <br>
             <input type="hidden" value="{{ csrf_token() }}" name="_token">
            </div>
     </form>

    <div class="thumbnail">
                
            <img src={{$image->images}} alt="Image could not be found" width="200px" height="200px">
     </div>


   </li>

         @endforeach

            </ul>

        </div>

        </center>

   </div>


   <div  class="col-md-4">  
        <center>
         <div id = "edit" class="well">

            @if(session()->has('successMessage2'))
              <div class="alert alert-success">
                  {{ session()->get('successMessage2') }}
            </div>
           @endif

            <ul id="sortable2">

           @foreach($background as $key=>$image)
        
   <li id="{{$key}}" class="ui-state-default"><span class="ui-icon ui-icon-arrowthick-2-n-s"></span>
       
     <form  method="POST" action="/Delete/background">
        <div class="form-group">
             <input type="hidden" name="BackgroundID" value="{{$image->id}}">
             <input type="hidden" name="BackgroundName" value="{{$image->imagesName}}">
             <input class="btn btn-danger" type="submit" value="Delete" name="submit">
             <br>
             <input type="hidden" value="{{ csrf_token() }}" name="_token">
            </div>
     </form>

    <div class="thumbnail">
                
            <img src={{$image->imagesName}} alt="Image could not be found" width="200px" height="200px">
     </div>


   </li>

         @endforeach

            </ul>

        </div>

        </center>

   </div>



  <div  class="col-md-4">  
        <center>
         <div id = "edit" class="well">

            @if(session()->has('successMessage3'))
              <div class="alert alert-success">
                  {{ session()->get('successMessage3') }}
            </div>
           @endif

            <ul id="sortable2">

           @foreach($gallery as $key=>$photo)
        
   <li id="{{$key}}" class="ui-state-default"><span class="ui-icon ui-icon-arrowthick-2-n-s"></span>
       
     <form  method="POST" action="/Delete/Gallery">
        <div class="form-group">
             <input type="hidden" name="photoID" value="{{$photo->id}}">
             <input type="hidden" name="photoName" value="{{$photo->image}}">
             <input class="btn btn-danger" type="submit" value="Delete" name="submit">
             <br>
             <input type="hidden" value="{{ csrf_token() }}" name="_token">
            </div>
     </form>

    <div class="thumbnail">
                
            <img src={{$photo->image}} alt="Image could not be found" width="200px" height="200px">
     </div>


   </li>

         @endforeach

            </ul>

        </div>

        </center>

   </div>

     
</div>
     
</div>

       <div class="row">

   <div  class="col-md-4">  
        <div class=well>
          
 @if(count($errors))
            <div class="alert alert-danger">
                <strong>Whoops!</strong> Please upload a image
                <br/>
                <ul>
                    @foreach($errors->all() as $error)
                    <li>{{ $error }}</li>
                    @endforeach
                </ul>
            </div>

  @endif


@if(session()->has('message'))
    <div class="alert alert-success">
        {{ session()->get('message') }}
    </div>
@endif

        <form action="{{ URL::to('Upload') }}" method="POST"   enctype="multipart/form-data">
            <div class="form-group">
             <label>To upload to slide show</label> 
             <input type="file" name="file" id ="file">
             <br>
             <input class="btn btn-default" type="submit" value="Upload" name="submit">
             <br>
             <input type="hidden" value="{{ csrf_token() }}" name="_token">
            </div>
        </form>
       </div>
   </div>

{{--Radio Background--}}

 <div  class="col-md-4">  
        <div class=well>
          
 @if(count($errors))
            <div class="alert alert-danger">
                <strong>Whoops!</strong> Please upload a image
                <br/>
                <ul>
                    @foreach($errors->all() as $error)
                    <li>{{ $error }}</li>
                    @endforeach
                </ul>
            </div>

  @endif


@if(session()->has('message2'))
    <div class="alert alert-success">
        {{ session()->get('message2') }}
    </div>
@endif

        <form action="/Upload/BackgroundImage" method="POST"   enctype="multipart/form-data">
            <div class="form-group">
             <label>To upload to Radio Background</label> 
             <input type="file" name="file" id ="file">
             <br>
             <input class="btn btn-default" type="submit" value="Upload Background" name="submit">
             <br>
             <input type="hidden" value="{{ csrf_token() }}" name="_token">
            </div>
        </form>
       </div>
   </div>


<div  class="col-md-4">  
        <div class=well>
          
 @if(count($errors))
            <div class="alert alert-danger">
                <strong>Whoops!</strong> Please upload a image
                <br/>
                <ul>
                    @foreach($errors->all() as $error)
                    <li>{{ $error }}</li>
                    @endforeach
                </ul>
            </div>

  @endif


@if(session()->has('message'))
    <div class="alert alert-success">
        {{ session()->get('message') }}
    </div>
@endif

        <form action="Upload/Gallery" method="POST"   enctype="multipart/form-data">
            <div class="form-group">
             <label>To upload to gallery</label> 
             <input type="file" name="file" id ="file">
             <br>
             <input class="btn btn-default" type="submit" value="Upload" name="submit">
             <br>
             <input type="hidden" value="{{ csrf_token() }}" name="_token">
            </div>
        </form>
       </div>
   </div>

<div class="row">
  

  <div  class="col-md-4">  
        <center>
         <div id = "edit" class="well">

            @if(session()->has('successMessage2'))
              <div class="alert alert-success">
                  {{ session()->get('successMessage2') }}
            </div>
           @endif

            <ul id="sortable2">

           @foreach($video as $key=>$vid)
        
   <li id="{{$key}}" class="ui-state-default"><span class="ui-icon ui-icon-arrowthick-2-n-s"></span>
       
     <form  method="POST" action="/Delete/Video">
        <div class="form-group">
             <input type="hidden" name="VideoID" value="{{$vid->id}}">
             <input class="btn btn-danger" type="submit" value="Delete" name="submit">
             <br>
             <input type="hidden" value="{{ csrf_token() }}" name="_token">
            </div>
     </form>

    <div class="thumbnail">
        
        <iframe class="frame" width="200" height="315" src={{$vid->url}} frameborder="0" allowfullscreen></iframe>

      
     </div>


   </li>

         @endforeach

            </ul>

        </div>

        </center>

   </div>

</div>


<div class="row">

  <div  class="col-md-4">  
        <div class=well>
          
 @if(count($errors))
            <div class="alert alert-danger">
                <strong>Whoops!</strong> Please upload a image
                <br/>
                <ul>
                    @foreach($errors->all() as $error)
                    <li>{{ $error }}</li>
                    @endforeach
                </ul>
            </div>

  @endif


@if(session()->has('message'))
    <div class="alert alert-success">
        {{ session()->get('message') }}
    </div>
@endif

        <form action="Upload/Video" method="POST">
            <div class="form-group">
             <label>To upload to video</label> 
             <br>
             <label>Enter a YoutTube video embed URL</label> 
             <br>
             <input type="text form-control-plaintext" name="url" id ="url" placeholder="https://www.youtube.com/embed/l9Lr5Lf1NI0">
             <br>
             <br>
             <input class="btn btn-default" type="submit" value="Upload video" name="submit">
             <br>
             <input type="hidden" value="{{ csrf_token() }}" name="_token">
            </div>
        </form>
       </div>
   </div>

</div>

</div> {{-- end of web container--}}



@endsection



@section("footer")


@include("includes.footer")

@endsection 
