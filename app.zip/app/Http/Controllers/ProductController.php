<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Requests;
use Illuminate\Support\Facades\DB;


class ProductController extends Controller
{
      public function __construct()
    {
        $this->middleware('auth');
    }


public function store(Request $request){
  
 	$this->validate($request,[

 		     'date' => 'required',
             
             'name'=> 'required|max:50',

             'email'=>'required|email',

             'address'=>'required|max:50',

             'state' => 'required',

             'city' => 'required|max:50',

              'zipCode' => 'required',

              'StartTime' => 'required',

              'EndTime' => 'required', 

             'Number' => 'required|integer',

             'phoneNumber' => 'required|max:10',

             'Carrier' => 'required',

 		]);


 	    $products = \App\Product::all();

            session([
            	    'date' => $request->date,
            	    'name' => $request->name, 
                    'email'=> $request->email, 
                    'address' => $request->address, 
                    'state' => $request->state, 
                    'city'=> $request->city, 
                    'zipCode'=> $request->zipCode, 
                    'StartTime' => $request->StartTime, 
                    'EndTime' => $request->EndTime, 
                    'Number'=> $request->Number, 
                    'phoneNumber' => $request->phoneNumber,
                    'Carrier' => $request->Carrier,
                    ]);

 	    // might be a better way but we are going to use sessions to store data 
        
        return view('Payment', compact('products'));

 }
}
