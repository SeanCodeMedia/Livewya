<?php

namespace App\Http\Controllers;
use App\Http\Requests;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class BookPartyController extends Controller
{
    
  public function __construct()
    {
        $this->middleware('auth');
    }

 public function BookParty(Request $request,$id)
    {
        


      return view('BookParty',["date" => $id]);

    }



 


}
