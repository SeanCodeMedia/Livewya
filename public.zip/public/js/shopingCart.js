





































































































  
  total = 0; 
  function check () {
    
    var  radio  = document.getElementById('photos').checked
    
    number = 50; 

    if (radio == true){

         $("#total").before("<p id = 'photoID'> Cost to take photos $"+number+"</p>");  

         total = total+50;  

           $("#totaling").remove();
            $("#total").after('<p id="totaling">$'+total+'</p>')
          
    } else if(radio == false){

            total = total-50;       

            $("#photoID").remove();
            
              $("#totaling").remove();
            $("#total").after('<p id="totaling">$'+total+'</p>')
           
    }



     }


  function check2 () {
    
    var  radio  = document.getElementById('videos').checked
    
    number = 50; 

    if (radio == true){

         $("#total").before("<p id = 'VideoID'> Cost to flim video $"+number+"</p>");  

         total = total+50;  

           $("#totaling").remove();
            $("#total").after('<p id="totaling">$'+total+'</p>')
          
    } else if(radio == false){

            total = total-50;       

            $("#VideoID").remove();
            
              $("#totaling").remove();
            $("#total").after('<p id="totaling">$'+total+'</p>')
           
    }



     }




$(document).ready(function() {
    
    var number = 350;
    var number2 = 50; 
    var number3 = 50; 


	$("#total").before('Cost to DJ party $' + number); 

  total = total+350; 

    $("#totaling").remove();
    $("#total").after('<p id="totaling">$'+total+'</p>')

  

     

});