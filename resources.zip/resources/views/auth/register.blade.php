@extends("layouts.masterLayout")

@include("includes.navBar")

<?php $title = "LiveWya|Register"?> 

@section('container')
<style type="text/css">
    body{

        background-color: #19B5FE;
    }
</style>

<link rel="stylesheet" type="text/css" href="css/signUp.css">

<div id="box" class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div id="panel" class=" animated bounceInUp panel panel-default">
                <div id="panelHead" class="panel-heading">Register</div>
                <div  class="panel-body">
                    <form class="form-horizontal" role="form" method="POST" action="{{ route('register') }}">
                        {{ csrf_field() }}

                        <div class="form-group {{ $errors->has('name') ? ' has-error' : '' }}">
                            <label for="name" class="col-md-4 control-label">First Name</label>

                            <div class="col-md-6">
                                <input id="name" type="text" class="form-control" name="name" value="{{ old('name') }}" required autofocus>

                                @if ($errors->has('name'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('name') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>

                         <div class="form-group {{ $errors->has('last') ? ' has-error' : '' }}">
                            <label for="name" class="col-md-4 control-label">Last Name</label>

                            <div class="col-md-6">
                                <input id="name" type="text" class="form-control" name="lastName" value="{{ old('last') }}" required autofocus>

                                @if ($errors->has('name'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('last') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>

                        <div class="form-group{{ $errors->has('email') ? ' has-error' : '' }}">
                            <label for="email" class="col-md-4 control-label">E-Mail Address</label>

                            <div class="col-md-6">
                                <input id="email" type="email" class="form-control" name="email" value="{{ old('email') }}" required>

                                @if ($errors->has('email'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('email') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>

                        <div class="form-group{{ $errors->has('password') ? ' has-error' : '' }}">
                            <label for="password" class="col-md-4 control-label">Password</label>

                            <div class="col-md-6">
                                <input id="password" type="password" class="form-control" name="password" required>

                                @if ($errors->has('password'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('password') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="password-confirm" class="col-md-4 control-label">Confirm Password</label>

                            <div class="col-md-6">
                                <input id="password-confirm" type="password" class="form-control" name="password_confirmation" required>
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="PhoneNumber" class="col-md-4 control-label">Phone Number</label>

                            <div class="col-md-6">
                                <input id="PhoneNumber" type="tel" class="form-control" 
                                name="phoneNumber" required>
                            </div>
                        </div>
<strong><small class="form-group" style="color:red; position:relative; left:150px; 
padding:1px!important;">*Please note if carrier is incorrect livewya will not be able to send you text messages </small></strong>

<div class="form-group">
<label for="phoneCarrier" class="col-md-4 control-label" >Phone Carrier
</label>
<div class="col-md-6"> 
<select name="Carrier"  class="form-control" required>
  <option value="">Please Select A Phone Carrier</option>      
  <option value="att">AT &amp;T</option>
  <option value="airfiremobile">Air Fire Mobile</option>
  <option value="alaskacommunicates">Alaska Communicates</option>
  <option value="ameritech">Ameritech</option>
  <option value=" moostmobile">Boost Mobile</option>
  <option value="cleartalk">Clear Talk</option>
  <option value="cricket">Cricket</option>
  <option value="metropcs">Metro PCS</option>
  <option value="nextech">NexTech</option>
  <option value="projectfi"> Project Fi</option>
  <option value="unicel">Unicel</option>
  <option value="verizonwireless">Verizon Wireless</option>
  <option value="virginmobile">Virgin Mobile</option>
  <option value="tmobile">T-Mobile</option>
  <option value="sprint">Sprint</option>
  <option value="uscellular"> US Cellular</option>
  <option value="null">Other</option>
</select>  
</div>
</div>
                        <div class="form-group">
                            <div class="col-md-6 col-md-offset-4">
                                <button type="submit" class="btn btn-primary">
                                    Register
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
