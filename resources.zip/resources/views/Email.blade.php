
<strong>Hello Sean, Jermaine, Davin, and David,</strong>

<p> 
     {{$name}}, just book a party with us for the {{$date}}.  The party will be located at {{$address." ". $city ." ". $zipCode." ".$state}} The party starts at {{$StartTime}} and ends at {{$EndTime}}. Their will be {{$Number}} of people attending the party. Here is 
     {{$name}} phone number {{$phoneNumber}} if you guys have any questions. 

<p>

<strong>Livewya.com Server testing BETA MODE !!!</strong>

