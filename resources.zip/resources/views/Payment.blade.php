@extends("layouts.masterLayout")

@include("includes.navBar")

<?php $title = "LiveWya|Payment"?> 

@section("container")
<link rel="stylesheet" href="{{ asset('public/css/Payment.css') }}">


<style type="text/css">
    body{
        background-color:#27ae60;
    }
</style>


<div  class=" row container">
<div class = "col-md-8 col-md-offset-2">
<div id="panel"class="panel panel-default">
  <div class="panel-heading">Payment</div>
  <div class="panel-body">
 
<div class="row">
            @foreach ($products as $product)
                <center><form action="{{ route('pay', $product->id) }}" method="POST">
                    {{ csrf_field() }}
                    <div class="col-md-8 col-md-8">
                        <div id = {{"package".$product->id}} class=" thumbnail">

                             @if($product->id == 1)

                             <style type="text/css">
                                
                                #package1{

                                   background-color:#bdc3c7;
                                }

                             </style>

                             @endif


                         @if($product->id == 2)

                             <style type="text/css">
                                
                                #package2{

                                   background-color:#e5e4e2;
                                }

                             </style>

                             @endif


                        @if($product->id == 3)

                             <style type="text/css">
                                
                                #package3{

                                   background-color:#cd7f32 ;
                                }

                             </style>

                             @endif

                        @if($product->id == 4)

                             <style type="text/css">
                                
                                #package4{

                                   background-color:#D4AF37;
                                }

                             </style>

                             @endif



                            <div class=caption">
                                <h3>{{ $product->name }}</h3>
                                <p>{{ $product->description }}</p>
                                <p>Book Party for  ${{ substr_replace($product->price, '.', 3, 0) }}</p>
                                   
                                <p>
                                    <script
                                        src="https://checkout.stripe.com/checkout.js" class="stripe-button"
                                        data-key="{{ env('STRIPE_KEY') }}"
                                        data-amount="{{ $product->price }}"
                                        data-name="Stripe.com"
                                        data-description="Widget"
                                        data-locale="auto"
                                        data-currency="usd">
                                    </script>
                                </p>
                            </div>
                        </div>
                    </div>
                </form>
                </center>
            @endforeach
        </div>
 
    </div>
</div>

  </div>
</div>
</div>
</div>




  </div>
</div>
</div>

</div>
@stop