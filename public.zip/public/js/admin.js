
// last updated 1/1/2018 

isOff = false; 

function checkDJ (){
	  

	  $("#autoDJ").html("<div id='text'><strong>Please wait..</strong></div>");

      $.get('/autoDJ', function(data) {

      	     $("#autoDJ").removeClass('btn btn-primary btn-lg');

      	     $("#text").remove(); 

      	     if( data == 1) {
                   
                  
                  $("#text").remove(); 

      	     	  $("#autoDJ").removeClass('btn btn-danger btn-lg');

      	     	 $("#autoDJ").addClass('btn btn-success btn-lg'); 
                 
                  $("#autoDJ").html("<div id='text'><strong>Turn Off Auto DJ</strong></div>");

                   isOff = false; 


      	     }   
             
               else if (data == 0) {

               	  $("#autoDJ").removeClass('btn btn-success btn-lg');

                  $("#autoDJ").addClass('btn btn-danger btn-lg'); 

                  $("#autoDJ").html("<div id='text'><strong>Turn On Auto DJ</strong></div>");


                  isOff = true;


               }
         	

         });


}

$(document).ready(function() {

checkDJ();

$('#welcome').fadeIn(800).delay(5000).fadeOut(800);

$('#welcome').fadeIn(1000).delay(10000).fadeOut(2000).css('diplay', 'none');



$("#autoDJ").click(function(event) {

	
           
       if(isOff == false){ /// dj is on 

     $.post("http://voscast.com/api/?key=3398c03beb672b3e4e8824a06466f821&action=stop");

       	$.ajaxSetup({
        headers: {
        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
           }
           });                    

        $.post('/UpdateDJ', {'state': '0'}, function(data) {
                     
                   checkDJ()
               
               });



       } else if(isOff == true){

          // dj is off  // turn on dj 



      $.post("http://voscast.com/api/?key=3398c03beb672b3e4e8824a06466f821&action=start")
       
       	$.ajaxSetup({
        headers: {
        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')


           }
           });                    

        $.post('/UpdateDJ', {'state': '1'}, function(data) {
                     
                   checkDJ()
               
               });
  }

});



$( "#sortable" ).sortable();
$( "#sortable" ).disableSelection();


var idsInOrder = $("#sortable").sortable("toArray");


$( "#sortable2" ).sortable();
$( "#sortable2" ).disableSelection();


var idsInOrder = $("#sortable2").sortable("toArray");


//alert(idsInOrder)

});


