
<?php 
/* Local server 
$dbname = "live_wya";
$username = "root";
$password = "";
$host = "127.0.0.1";
*/

$dbname = "livewya";
$username = "livewyadata";
$password = "Myjamaicaboys237";
$host = "mysqlcluster19.registeredsite.com";





$dataBase = mysqli_connect($host,$username,$password,$dbname) or die ("cannot connect to data base :(");

mysqli_select_db($dataBase,$dbname) or die ("cannot select DB"); 




?>