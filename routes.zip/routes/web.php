<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
}

);


Route::get('/Radio','RadioController@GotoRadio');

Route::get('/Contact','contactController@show');

Route::post('/Upload','uploadImage@upload');

Route::post('/Delete','uploadImage@Delete');

Route::post('/Delete/background','uploadImage@Deletebackground');

Route::post('/Upload/BackgroundImage','uploadImage@uploadBackgroundImage');

Route::post('/GetImages','uploadImage@GetImages');

Route::post('Upload/Gallery','uploadImage@UploadGallery');

Route::post('/Delete/Gallery','uploadImage@DeleteGallery');

Route::post('/Upload/Video','uploadImage@Uploadvideo');

Route::post('/Delete/Video','uploadImage@DeleteVideo');

//Route::get('/AlbumCover','AlbumCover@Getcover');

Route::get('/Bookings','BookingsController@GotoBookings');

Route::get('/Videos','videosController@show');

Route::get('/Gallery','galleryController@show');

Route::get('/Tickets','ticketsController@show');

Route::get('/Blog','blogController@show');

Route::get('/News','newsController@show');


Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');


Auth::routes();

Route::get('/Dashboard', 'AdminController@show');


Auth::routes();

Route::get('/autoDJ','AdminController@autoDJ');



Route::post('/UpdateDJ', 'AdminController@UpdateAutoPlay');




// Route::get('/autoDJ', function () {
     
//      return "get data from model";

// })->middleware('hide');

Auth::routes();
Route::get('/BookParty/{date}', 'BookPartyController@BookParty');

Auth::routes();

Route::post('/Payment','ProductController@store');

Route::get('logout', '\App\Http\Controllers\Auth\LoginController@logout');

////////////////////////////Payment system/////////////////////////////////////////////////
Route::auth();


// Product Routes
// Route::get('/', [
//     'uses' => 'ProductController@index',
//     'as' => 'index',
//     'middleware' => 'auth'
// ]);





// Route::get('/admin', [
//     'uses' => 'OrderController@getAllOrders',
//     'as' => 'admin',
//     'middleware' => 'hide'
// ]);
 
// Order Routes
Route::get('/admin', [
    'uses' => 'OrderController@getAllOrders',
    'as' => 'admin',
    'middleware' => 'admin'
]);
 
Route::post('/pay/{product}', [
    'uses' => 'OrderController@postPayWithStripe',
    'as' => 'pay',
    'middleware' => 'auth'
]);
 
Route::post('/store', [
    'uses' => 'OrderController@postPayWithStripe',
    'as' => 'store',
    'middleware' => 'auth'
]);
