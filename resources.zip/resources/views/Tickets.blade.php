@extends("layouts.masterLayout")

@include("includes.navBar")

<?php $title = "LiveWya|Tickets"?> 

@section('container')
<script type="text/javascript" src="public/js/videos.js"></script>
<div class="container">
<br>
<br>
<br>
<center>

<h1>For tickets please contact</h1>

<br>
<br>

<h1 id="fade" class="animated fadeIn">Under Construction</h1>

</center>

</div>
@endsection