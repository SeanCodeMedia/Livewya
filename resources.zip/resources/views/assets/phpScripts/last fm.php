<?php 

error_reporting(0);

$artist = "bob marley"; 

if(isset($_POST["songData"])){
  

   $artist =  $_POST["songData"];


}
 

$xmlData =  simplexml_load_file("http://ws.audioscrobbler.com/2.0/?method=artist.getinfo&artist=".$artist."&api_key=c6c7a34aeddef633d952a21afda40e4e"); 


$jsonData = json_encode($xmlData); 


$newXML = json_decode($jsonData,true); 


echo($newXML["artist"]["bio"]["content"]);

?> 