@extends("layouts.masterLayout")

@include("includes.navBar")

<?php $title = "LiveWya|Gallery"?> 

@section('container')

<link rel="stylesheet" type="text/css" href="css/gallery.css">


<script type="text/javascript" src="js/background.js"></script>

<div id="bg">

</div>

<div class="container">

<br>
<br>
<br>
<center>
<div class="well">

<div class="row">
@foreach ($data as $images)

  <div class="col-md-4">
    
    <a href="#" class="thumbnail">
      <img class="image" class="img-responsive" src="{{$images->image}}">
    </a>

  </div>

@endforeach
</div>
</div>
</center>

</div>

@endsection


@section("footer")


@include("includes.footer")

@endsection 
