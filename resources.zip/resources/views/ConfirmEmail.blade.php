

<strong>Hello {{$name}}, </strong>

<p>We just got your request to play a party on {{$date}} we will contact you soon</p>

<p>Thank you from the livewya team</p>