
<?php
/*
mysqlcluster3 - wya_live - Rosezaten1
*/

include("connect.php");

$sql = "SELECT * FROM undates";
$result = mysqli_query($dataBase,$sql); 


$Json = array(); 
 

if ($result){
	  
	   while($row = mysqli_fetch_assoc($result)) {
           
		  
		   
		  array_push($Json,$row['dates'],$row['tooltip'],$row['poster']);
           
		  
	  }

} else {
	 
	 echo "check your query";
	
	}

echo json_encode($Json);

	
  	      
	



?>