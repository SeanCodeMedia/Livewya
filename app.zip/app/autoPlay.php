<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class autoPlay extends Model
{
    

    public $table = "autoMusic";
}
