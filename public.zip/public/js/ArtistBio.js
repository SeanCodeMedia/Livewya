
$(document).ready(function($) {

  var SongID = $("#currentSong > div").attr('id'); 

 
 var playingNow = $("#"+SongID).html().toLowerCase()


 function titleCase(str) {
    var splitStr = str.toLowerCase().split(' ');
    for (var i = 0; i < splitStr.length; i++) {
        // You do not need to check if i is larger than splitStr length, as your for does that for you
        // Assign it back to the array
        splitStr[i] = splitStr[i].charAt(0).toUpperCase() + splitStr[i].substring(1);     
    }
//    // Directly return the joined string
    return splitStr.join(' '); 
 }

   for(var i= 0;  i < playingNow.length; i++){
      

   if(playingNow[i] == "ft"){
     

        var cut = playingNow.substr(0, i); 

        console.log(cut);


        break;

	} else if (playingNow[i] == "feat") {

		   var cut = playingNow.substr(0, i); 

        console.log(cut);


        break;
	} else if (playingNow[i] == "-") {

		   var cut = playingNow.substr(0, i); 

        console.log(cut);


        break;
	}


}
	
         $.post('/js/last fm.php', {"songData": $.trim(cut).replace(/\W/g, ' ').replace("-","")}, function(data) {

         	    $("#well01").css('display', 'block');
         	    $("#well01").addClass(' animated fadeIn')

         	    setTimeout(function () {
         	    	 $("#well01").removeClass('animated fadeOut')
         	    }, 2000);

               
                 console.log(data);

                if($.trim(data) == "Array"||  cut == " "){

                	 $("#artistName").empty()
               
                if($.trim(data) == "Array"){

                  $("#artistName").append('Biography of ' + titleCase(cut))
              }   
                  $("#BioContent").empty(); 
                 $("#BioContent").append("Biograhy was not found !"); 


                } else {


                 $("#artistName").empty()
                 $("#artistName").append('Biography of ' + titleCase(cut))
                 $("#BioContent").empty(); 
                $("#BioContent").append(data) 


               }
        	
               
       });

});