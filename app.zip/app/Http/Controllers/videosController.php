<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\video;


class videosController extends Controller
{
   

public function show()
{    
	 
	$videos = video::all(); 

    $videosArray = array();

  foreach ($videos as $video) {

    array_push($videosArray,$video->url);
}

	return view("videos")->with("data",$videosArray);

}


}
