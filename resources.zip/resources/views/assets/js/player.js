// JavaScript Document
// updated 2.0

$(document).ready( function() {

console.log("ready!");


playerInstance = jwplayer("radio");

jwplayer.key = "y5J6LSVMPE4KtTFykuCDgvvwgPeDRpiiUnfRsA=="
// jw player API key 
playerInstance.setup({
   // link to vocast server 
  flashplayer: "jwplayer.flash.swf",
    file: "http://s6.voscast.com:9368/;stream.mp3",
    flashvars: 'ignoremeta=true',
  autostart: true,
  image:"/assets/images/logo.jpg"
  
});
  
});


var Amazon_Request  = null ;


var SongID = $("#currentSong > div").attr('id'); 

console.log(SongID);

var d = null; 


function titleCase(str) {
   var splitStr = str.toLowerCase().split(' ');
   for (var i = 0; i < splitStr.length; i++) {
       // You do not need to check if i is larger than splitStr length, as your for does that for you
       // Assign it back to the array
       splitStr[i] = splitStr[i].charAt(0).toUpperCase() + splitStr[i].substring(1);     
   }
   // Directly return the joined string
   return splitStr.join(' '); 
}



found = true; 

foundBio = true;


$.post('/assets/phpScripts/amazon.php', function(data) {

 	console.log(data);

	

$("#Album_cover").css('backgroundImage','url("'+$.trim(data)+'")');


 });






$.get('/assets/textfiles/artist.txt', function(data) {

	   d2 = data.toLowerCase()

	   d = d2.split("\n");


      GetAlbumCover(); 


}); 


function checkDiv () {

	// check if text change in current song div 

  $("#"+SongID).bind("DOMSubtreeModified",function(){
    
    console.log("DOM Changed"); 

    $("#"+SongID).addClass('animated fadeInUp');


    setTimeout(function () {
    	 $("#"+SongID).removeClass('animated fadeOutDown'); 
    }, 2000)

  	GetAlbumCover() 

});
 
}


 setTimeout(function () {
  checkDiv() 
 }, 1000)

function GetAlbumCover() { 
/// http://www.dreamincode.net/forums/topic/247188-user-authentication-class

if( found == true ){

	console.log("ranned 1")

var playingNow = $("#"+SongID).html().toLowerCase()

for(var i= 0;  i < playingNow.length; i++){
      

   if(playingNow[i] == "-"){
      


        var cut = playingNow.substr(0, i); 

        if(cut == " "){

        	   found = false 
                
               GetAlbumCover(); 

        
       }  
       
        $.post('/assets/phpScripts/amazon.php', {"songData": $.trim(cut).replace(/\W/g, ' ').replace("-","")}, function(data) {

        	     console.log(data);

              $("#well01").css('display', 'block');
        	    $("#well01").addClass(' animated fadeIn')

        	    setTimeout(function () {
        	    	 $("#well01").removeClass('animated fadeOut')
        	    }, 2000);



               if($.trim(data) == "Array"||  cut == " "){

               	 $("#artistName").empty()
               
               if($.trim(data) == "Array"){

                 $("#artistName").append('Biography of ' + titleCase(cut))
             }   
                 $("#BioContent").empty(); 
                 $("#BioContent").append("Biograhy was not found !"); 


               } else {


                $("#artistName").empty()
                $("#artistName").append('Biography of ' + titleCase(cut))
                $("#BioContent").empty(); 
                $("#BioContent").append(data) 


               }
        	
               
        });


         $.post('/assets/phpScripts/amazon.php', {"songData": cut}, function(data) {
        	 
                      console.log(data);
                var error = $.trim(data).includes("Notice"); 

             //   console.log("error >>>>"+error)



             if(error == true){

             	found = false 
                
                 GetAlbumCover(); 

             }
              

                console.log(data)



                console.log("found a dash to send"); 

               $("#Album_cover").addClass('animated fadeIn'); 

               $("#Album_cover").css("display","block")

               $("#Album_cover").css('backgroundImage','url("'+$.trim(data)+'")');

              setTimeout(function () {
               	
               	      $("#Album_cover").removeClass('animated fadeOut');
               }, 2000)
         

      
   })
      

}
   
     } 
}
      else if (found == false) {

      	found = true 

      	console.log("ranned 2")

       var currentSong = $("#"+SongID).html().replace(/\W/g, ' ').toLowerCase();
    

	 var string = currentSong.toLowerCase();


    for (var i = 0; i < d.length; i++) {
    
	      var val = $.trim(d[i])

           isInarray = string.includes(val)

           console.log(isInarray)

        if(isInarray == true ){

        	 console.log("found a match to send to amazon");


        	 Amazon_Request = d[i]; 

        $.post('/assets/phpScripts/last fm.php', {"songData": $.trim(Amazon_Request).replace(/\W/g, ' ').replace("-","")}, function(data) {
                      console.log(data);
                 $("#well01").css('display', 'block');
        	    $("#well01").addClass(' animated fadeIn')

        	    setTimeout(function () {
        	    	 $("#well01").removeClass('animated fadeOut')
        	    }, 2000);


               if($.trim(data) == "Array" || Amazon_Request == " "){

               	 $("#artistName").empty()
               	 
               	  if($.trim(data) == "Array"){

                 $("#artistName").append('Biography of ' + titleCase(Amazon_Request))
             }   
                  $("#BioContent").empty(); 
                 $("#BioContent").append("Was not found by Livewya!"); 


               } else {


               	 $("#artistName").empty()
                 $("#artistName").append('Biography of ' + titleCase(Amazon_Request))
                 $("#BioContent").empty(); 
                 $("#BioContent").append(data)

               }
 
                 

             });



        	 $.post('/assets/phpScripts/amazon.php', {"songData": Amazon_Request}, function(data) {
        	 	 
                        console.log(data)

               $("#Album_cover").addClass('animated fadeIn'); 

                 $("#Album_cover").css("display","block")

               $("#Album_cover").css('backgroundImage','url("'+$.trim(data)+'")');
               
               setTimeout(function () {
               	
               	      $("#Album_cover").removeClass('animated fadeOut');
               }, 2000)
         


        	 });
 
        	 break 
	
        }

	 }
        }
   
}
/// url and command 
//http://webservices.amazon.com/scratchpad/index.html#http://webservices.amazon.com/onca/xml?Service=AWSECommerceService&Operation=ItemSearch&SubscriptionId=AKIAIIFFJYWIGQWQVYMQ&AssociateTag=livstu09-20 &SearchIndex=Music&Keywords=chronixx&ResponseGroup=Images,Offers
// https://en.wikipedia.org/w/api.php?format=xml&action=query&prop=extracts&explaintext=&titles=chronixx
// C:\Users\SeanDp32>start chrome.exe --user-data-dir="C:/Chrome dev session" --disable-web-security




