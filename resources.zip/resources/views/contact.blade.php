@extends("layouts.masterLayout")

@include("includes.navBar")

<?php $title = "LiveWya|Contact us"?> 

<link rel="stylesheet" type="text/css" href="{{ asset('public/css/contact.css') }}">

<link rel="stylesheet" type="text/css" href="{{ asset('public/css/animate.css') }}"

@section('container')
<center>
<div class="container">
  
   <div class="well">
   	   
   	    <h4><strong>Contact us at:</strong></h4>

   	  <strong>(609)456-5595</strong>   
   	    <br>
   	    <br>
   	   <strong> (973) 905-9740</strong>  
   	    <br>
   	    <br>
   	    <strong> (609)424-8375 </strong>   <br>
   	    <br>
         <strong> send us a fast email <strong>
         <br>
         <br>
   	    <button type="button" class="btn btn-primary">Fast email</button>


   </div>

</div>
</center>
@endsection