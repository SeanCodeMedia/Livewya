@extends("layouts.masterLayout")

@include("includes.navBar")

<?php $title = "LiveWya|Radio"?> 

<meta name="base_url" content="{{ asset('public/images/logo.jpg') }}">

<link rel="stylesheet" type="text/css" href='css/radio.css'>

@section("container")


<style type="text/css">
	body{background-color:#95a5a6;}
</style>

<script type="text/javascript" src="js/jwplayer-7.1.4/jwplayer.js"></script>

<!-- this just got mod--> 
<script type="text/javascript" src="js/Albumcover.js"></script>

<script type="text/javascript" src="js/ArtistBio.js"></script>

<script type="text/javascript" src="js/player.js"></script>

<script type="text/javascript" src="js/background.js"></script>


<div id="bg">

</div>

{{-- stay outside of container--}}



<div id="title">

   <div id = "currentSong">
        <!--VosCast.com SHOUTcast Server Stats-->
        <script type="text/javascript" src="http://cdn.voscast.com/stats/display.js?key=43d74fd92029036fddf021f4e6606167&stats=songtitle"></script>
        <!--End SHOUTcast Server Stats-->
        </div>
   
</div>

<div id = "Album_cover" class="thumbnail"> 

</div>


<div class="container webcontainer moveDown">


   <div class="row">

        <div  class="col-md-4"> 

         <div id="liveCameria">

				  <iframe id="live" class="frame" width="460" height="270" src="https://www.youtube.com/embed/live_stream?channel=UCd-sdbnIn3NQshYZdYvovUg&mute=1&controls=0" frameborder="0" allowfullscreen></iframe>

			</div>

         </div>



       <div  class="col-md-4"> 

            
		<div  class='container' id = "radio"> 

		</div>

       </div>



      <div  class="col-md-4"> 

<div id="carousel" class="carousel slide" data-ride="carousel">

    <!-- Items -->
    <div class="carousel-inner">
        
        @foreach($images as $key=>$image)
            
           @if($key == 1)

        <div class="item active">
           <div class="thumbnail">
            <img src="{{$image->images}}" alt="Image could not be found" />
           </div>
        </div>

        @endif

          <div class="item">
          	<div class="thumbnail">
            <img src="{{$image->images}}" alt="Image could not be found" />
           </div>
        </div>

        @endforeach 
      
    </div> 

    <a href="#carousel" class="left carousel-control" data-slide="prev">
        <span class="glyphicon glyphicon-chevron-left"></span>
    </a>
    <a href="#carousel" class="right carousel-control" data-slide="next">
        <span class="glyphicon glyphicon-chevron-right"></span>
    </a>
</div>




       </div>{{--end col-mod-4--}}

    </div> 


 <div class="row">
    <div  class="col-md-4"> 

	 	 <div id ="well01" class="well">

	  <strong><center><p id="artistName"></p></center></strong>


		  <p id="BioContent"> 
		      
		  </p>

        </div>

     </div> {{--end of col mod -4--}}


     <div  class="col-md-4"> 
      
      <div id="recentSongs" class="well">
            <center><h4> Recent Songs </h4></center> 
      <!--VosCast.com SHOUTcast Server Stats-->
<script type="text/javascript" src="http://cdn.voscast.com/stats/display.js?key=43d74fd92029036fddf021f4e6606167&stats=songhistory"></script>
<!--End SHOUTcast Server Stats-->

    </div>

     </div>

</div> {{--end of row--}}


</div>



@stop 


@section("footer")


@include("includes.footer")

@endsection 
