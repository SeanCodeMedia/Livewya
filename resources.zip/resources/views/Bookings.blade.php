@extends("layouts.masterLayout")

@include("includes.navBar")

<?php $title = "LiveWya|Bookings"?> 



@section("container")


<link href="css/jquery-ui.css">
<link href="css/jquery-ui.structure.css">
<link href="css/jquery-ui.theme.css">
<link rel="stylesheet" type="text/css" href="css/Bookings.css"> 
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
<script type="text/javascript" src="js/events.js"></script>

<script type="text/javascript" src="js/background.js"></script>

<div id="bg">

</div>

<style type="text/css">
	body{

		background-color:#FFB61E;
	}
</style>




  <div id="calinder_box" class="container"></div>
@stop



@section("footer")

@include("includes.footer")

@endsection 
