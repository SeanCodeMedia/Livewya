<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class DJpromoImages extends Model
{
    public $table = "PromoImages";
}
