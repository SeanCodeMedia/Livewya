$('.carousel').carousel({interval: 100})
		  
		 