<?php 

error_reporting(0);

function get_data($url) {
    $ch = curl_init();
    $timeout = 5;
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, $timeout);
    $data = curl_exec($ch);
    curl_close($ch);
    return $data;
}

$artist = "bob marley"; 

if(isset($_POST["songData"])){
  

   $artist =  $_POST["songData"];


}
 
$request_url = "http://ws.audioscrobbler.com/2.0/?method=artist.getinfo&artist=".$artist."&api_key=c6c7a34aeddef633d952a21afda40e4e"; 

//public server 
//$content = get_data($request_url); 


//$xml = simplexml_load_string($content) or die("something is wrong with request");

$xml =  simplexml_load_file($request_url) or die("something is worng with request");


$jsonData = json_encode($xml); 

$newXML = json_decode($jsonData,true); 


echo($newXML["artist"]["bio"]["content"]);

?> 