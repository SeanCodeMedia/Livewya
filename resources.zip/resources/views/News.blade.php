@extends("layouts.masterLayout")

@include("includes.navBar")

<?php $title = "LiveWya|News"?> 

@section('container')
<script type="text/javascript" src="public/js/videos.js"></script>
<div class="container">
<br>
<br>
<br>
<center>
<div><img src="http://marcellusdrilling.com/wp-content/uploads/2016/10/under-construction.png" width="400px" height="400px"></div>
<br>
<h1 id="fade" class="animated fadeIn">Under Construction</h1>
</center>

</div>
@endsection