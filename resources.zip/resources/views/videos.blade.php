@extends("layouts.masterLayout")

@include("includes.navBar")

<?php $title = "LiveWya|Video"?> 

<link rel="stylesheet" type="text/css" href="css/videos.css">


<div id="bg">


</div>

@section('container')

<script type="text/javascript" src="js/background.js"></script>


<div class="container">
<br>
<br>
<br>
<center>
<div class="well">

<center>
<div class="row">
 @foreach ($data as $vid => $videos)


  <div class="col-md-6">

 @if($vid == 1) 

<iframe style="position:relative; top:-36px;" class="frame" width="560" height="315" src={{$videos}} frameborder="0" allowfullscreen></iframe>

 @else

<iframe class="frame" width="560" height="315" src={{$videos}} frameborder="0" allowfullscreen></iframe>

@endif

</div>


<br>
<br>
 @endforeach
 </div>
</center>

</div>
</center>
</div>

@endsection


@section("footer")

@include("includes.footer")

@endsection 


