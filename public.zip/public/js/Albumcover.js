



$(document).ready(function() {

var windowWith = $(window).width();

function left(){

     $("#currentSong").animate({
      left: "+="+windowWith},30000, function() {
             $("#currentSong").css('left', "0").addClass('animated fadeIn');
             left();  // recursive call 
             $("#currentSong").removeClass('animated fadeIn');
    });


}

left()


var SongID = $("#currentSong > div").attr('id'); 

function GetAlbumCover() {	
   
var playingNow = $("#"+SongID).html().toLowerCase()

   for(var i= 0;  i < playingNow.length; i++){
      

   if(playingNow[i] == "ft"){
     

        var cut = playingNow.substr(0, i); 

      //  console.log(cut);


        break;

	} else if (playingNow[i] == "feat") {

		   var cut = playingNow.substr(0, i); 

       // console.log(cut);


        break;
	} else if (playingNow[i] == "-") {

		   var cut = playingNow.substr(0, i); 

        //console.log(cut);


        break;
	}


}

         $.post('/js/amazon.php', {"songData": cut}, function(data) {
        	 

              var error = $.trim(data).includes("Notice"); 

                
                if(error == false) {

                $("#Album_cover").fadeIn('slow');

                $("#Album_cover").css("display","block")

                $("#Album_cover").css('backgroundImage','url("'+$.trim(data)+'")');

        
            
             }  else if (error == true){


                   $("#Album_cover").fadeIn('slow');

                $("#Album_cover").css("display","block")

                $("#Album_cover").css('backgroundImage','url("images/logo.png")');


             }


      
   })

}


// function checkDiv () {

	// check if text change in current song div 

  $("#"+SongID).bind("DOMSubtreeModified",function(){


    $("#"+SongID).addClass('animated fadeInUp');


    //alert("chnaged")
         
    setTimeout(function () {
    	 $("#"+SongID).removeClass('animated fadeOutDown'); 
    }, 1000)

  	GetAlbumCover() 

$.ajax({
  url: '/js/ArtistBio.js',
  dataType: "script"
  
});





});
 
// }


 // setTimeout(function () {
 //  checkDiv();
 // }, 10000)


GetAlbumCover()
});