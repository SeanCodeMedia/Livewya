<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class video extends Model
{
    
public $table = "video";
}
