<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\DJpromoImages as promoImages; 



class RadioController extends Controller
{
    
 
     public function GotoRadio(){

     	   $images = promoImages::all();

               
           return view("Radio",compact('images')); 
     }


  

}
