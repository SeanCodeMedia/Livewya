<?php 



$flag;

$date = $email = $name = $address = $city = $state = $zip = $phone = $time = $time2 = $num_of_people = $tell_more =  "";
/*   

*/
       if (isset($_POST['var_name'])){
	
				$date = $_POST['var_name'];

	        echo($date);
			}

  
   if ($_SERVER['REQUEST_METHOD'] == 'POST') { 
       // read up more about preventing hackers 
	   
	   
	   if (isset($_POST['email'])){
		   
		   $email = check_hackers($_POST['email']);
		   
		   }
		   if (isset ($_POST['name'])){
			   
			    $name = check_hackers($_POST['name']);
			  
			  } 
			  
			if (isset($_POST['address'])){
				
				$address =  check_hackers($_POST['address']);
				
				}
			if (isset($_POST['city'])){
				 
				 $city = check_hackers($_POST['city']);  
				
			     }
			if (isset($_POST['state'])){
				
				$state = check_hackers($_POST['state']);  
				
				}
			if (isset($_POST['zip'])){
				
				$zip = check_hackers($_POST['zip']);  
				
				}
				
			if (isset($_POST['phone'])){
				
				 $phone = check_hackers($_POST['phone']);  
			
				}
	   
	   
	         if (isset($_POST['time'])){
				 
				  $time = check_hackers($_POST['time']);
				 
				 }
			if (isset($_POST['time2'])){
				
				$time2 = check_hackers($_POST['time2']);
				
				}
				
			if(isset($_POST['num_people'])){
				
				$num_of_people = check_hackers($_POST['num_people']);
				}
	   
	         if (isset($_POST['tell_us_more'])){
				 
				 $tell_more = check_hackers($_POST['tell_us_more']);

				 
				 } 
				 
				if (isset($_POST['dateOf'])){
					
					$date = check_hackers($_POST['dateOf']);
					
					}

	
	 
		if (isset($_POST['flager'])){
    
    		$flag = $_POST['flager'];
	
			if ($flag == true){  
  				sendMail($email,$name,$address,$city,$zip, $state, $phone,$time,$time2,$num_of_people,$tell_more,$date);
			}
	
}
	   
	
   }
      
	
	
   function check_hackers ($data){
	   
   $data = trim($data);
   $data = stripslashes($data);
   $data = htmlspecialchars($data);
   return $data;
	   
	 } 
	
/////////////////////////////email off information////////////////////////
        
		/*
		 "Hi David and Sean, \r\n".$name."book a party with us on".$date.".\r\n The party is located at". $address." ".$city." ".	$state." ".$zip." ".$name." phone number is".$phone.". The party is starting at ".$time."and end at".$time2."The will be ". $num_of_people. " peopleattending the party. here is the a more details about the party from".$name.". ".$tell_more."and".$name."email is".$email;
		*/

		
	 
   function sendMail($email,$name,$address,$city,$zip,$state,$phone,$time,$time2,$num_of_people,$tell_more,$date){
	    
		
	   	$send_to = "SeanDp32@gmail.com,Davidmpeart@gmail.com";
		$subject = $name." booked a party with live wya.com !"; 
		$Message =  "Hi David, and Sean, \r\n ".$name." book a party with us for the ".$date.". The party is located at ". $address." ".$city." ".$state." ".$zip." ".$name.". phone number is ".$phone.". The party starts at ".$time." and end at ".$time2.". "."There will be ". $num_of_people. " people attending the party. Here is more details about the party from ".$name.". ".$tell_more." and ".$name." email is ".$email."\r\n \r\n \r\n Have a nice day from the Live Wya Server do not reply to this email !";
		
		$headers = "From: <live wya.com server>" ."\r\n";
		$headers .= 'Cc: Davidmpeart@gmail.com, SeanDp32@gmail.com, '.$email;
		
		mail($send_to,$subject,$Message,$headers);
		
	   ////////////////////////send a email to the user/////////////////////////////////// 
	   
	   $userEmail = $email; 
	   $userSubject = "Thank you for booking your party with live wya.com !"; 
	   $Message2 = "Hi ".$name.",\r\n"."Thank you for booking your party with live wya.com. We are currently reviewing your submission we will contact you as soon as possible.If any questions you may have you can contact us at (609)-456-5593 or (609)-424-8375 \r\n Thank you for booking with live wya again ! Thank you from  \r\n Sean & Daivd" ;
	   
	   
	   mail($userEmail,$userSubject ,$Message2,$headers);
	   
	   
	  }
   







?>
