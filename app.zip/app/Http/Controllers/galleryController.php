<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use Illuminate\Support\Facades\DB;

use App\gallery as gallery;

class GalleryController extends Controller
{
    public function show()
{

    $data = gallery::all(); 

 	return view("gallery",compact('data'));

}

}
