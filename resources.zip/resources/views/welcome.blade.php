@extends("layouts.masterLayout")

@include("includes.navBar")

<?php $title = "LiveWya|welcome"?> 

@section("container")
<link rel="stylesheet" href="css/animate.css">
     
<div id="content1" class="carousel slide hider" data-ride="carousel">

  <!-- Wrapper for slides -->
  <div class="carousel-inner" role="listbox">
    <div class="item active">
      <img class="fill" width="1000px" height="1000px" src="https://i.guim.co.uk/img/media/a36d667c1d5e520c446acde081f0a44f324affea/0_29_4064_2437/master/4064.jpg?w=300&q=55&auto=format&usm=12&fit=max&s=fc94f9dfc0b3108c1a27856fd6e80a59" alt="...">
      <div class="carousel-caption">
        
      </div>
    </div>
   
   <div class="item">
      <img class="fill" width="1000px" height="1000px" src="https://s-media-cache-ak0.pinimg.com/originals/ae/16/41/ae1641a2b6914131966f468f299205cf.jpg" alt="...">
      <div class="carousel-caption">

      </div>
    </div>

    <div class="item">
      <img class="fill" width="1000px" height="1000px" src="http://www.tecnologiadj.com/wp-content/uploads/2013/06/Disena-tu-cabina-III-La-regla-WHW.jpg" alt="...">
      <div class="carousel-caption">

      </div>
    </div>
    
    <div class="item">
      <img class="fill" width="1000px" height="1000px" src="http://cdn.pcwallart.com/images/camera-wallpaper-2.jpg" alt="...">
      <div class="carousel-caption">
     
      </div>
    </div>

    <div class="item">
      <img class="fill" width="1000px" height="1000px" src="https://i.ytimg.com/vi/o322TIvmqtc/maxresdefault.jpg" alt="...">
      <div class="carousel-caption">
              </div>
    </div>
    
  </div>


</div>

<div  id = "slide01" class="container carousel-overlay text-center">
       <strong><h1>Welcome To Live Wya Radio </h1></strong> 
        <p class="lead">The Number One Sound</p>
     <a href="/Radio"><button type="button" class=" btn btn-primary btn-lg">Radio</button></a>
 <a href="/Bookings"> <button type="button" class="btn btn-primary btn-lg">Bookings</button></a>

</div>
</div>

{{-- <div id = "Content2" class="container">
 <img class="fill" width="1000px" height="1000px" src="http://raiot.in/wp-content/uploads/2017/03/6ae35127d96da911d08b89b9df5c36d2.jpg">
</div>

<div  id = "textBox1" class = "textBox" >
<p id ="text">
<strong>
    
    Welcome to live wya .com, the number one radio station in Newark NJ. 
We play a verity of music over our radio waves, from reggae to hip-hop we play it. 
We look to satisfy listeners from a verity of backgrounds. From Jamaican to Guyanese  background. We are not only a radio station, we can DJ your parties for a low cost of $300 U.S if you live in New Jersey. We will also stream your party live over the radio. So that latecomers are always at the party. We have listeners from all around the world, from Jamaica to England your party will be heard. For an additional price of $50 U.S we will record your party in full HD. We will also post the video on our website, and YouTube channel for easy viewing. Book live wya for your party and you will not be sorry.
</strong>
</p>

</div>


<div id = "Content2" class="container">
 <img class="fill" width="1000px" height="1000px" src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSeHvK2yVhiuizW-nCS_ZBqcTL9pZN-aGmpfkCjxwOqROzO8u5N">
</div>

<div id = "textBox2" class = "textBox" >
<p id ="text">
<strong>
    
    Welcome to live wya .com, the number one radio station in Newark NJ. 
We play a verity of music over our radio waves, from reggae to hip-hop we play it. 
We look to satisfy listeners from a verity of backgrounds. From Jamaican to Guyanese  background. We are not only a radio station, we can DJ your parties for a low cost of $300 U.S if you live in New Jersey. We will also stream your party live over the radio. So that latecomers are always at the party. We have listeners from all around the world, from Jamaica to England your party will be heard. For an additional price of $50 U.S we will record your party in full HD. We will also post the video on our website, and YouTube channel for easy viewing. Book live wya for your party and you will not be sorry.
</strong>
</p>

</div>


<div id = "Content2" class="container">
 <img class="fill" width="1000px" height="1000px" src="https://1wbs5o3gs4r83huhze5rq9nj-wpengine.netdna-ssl.com/wp-content/uploads/2017/03/resistanceradiotba-1.jpeg">
</div>

<div id = "textBox3" class = "textBox" >
<p id ="text">
<strong>
    
    Welcome to live wya .com, the number one radio station in Newark NJ. 
We play a verity of music over our radio waves, from reggae to hip-hop we play it. 
We look to satisfy listeners from a verity of backgrounds. From Jamaican to Guyanese  background. We are not only a radio station, we can DJ your parties for a low cost of $300 U.S if you live in New Jersey. We will also stream your party live over the radio. So that latecomers are always at the party. We have listeners from all around the world, from Jamaica to England your party will be heard. For an additional price of $50 U.S we will record your party in full HD. We will also post the video on our website, and YouTube channel for easy viewing. Book live wya for your party and you will not be sorry.
</strong>
</p>

</div>
<div class="container">
  <div class="col-md-10">

      @if(session('msg'))
          <div class="alert alert-success" role="alert">
              {{ session('msg') }}
          </div>
      @endif

      @if(session('error'))
          <div class="alert alert-danger" role="alert">
              {{ session('error') }}
          </div>
      @endif

      
<div class="container">
  <div class="col-md-10">

      @if(session('msg'))
          <div class="alert alert-success" role="alert">
              {{ session('msg') }}
          </div>
      @endif

      @if(session('error'))
          <div class="alert alert-danger" role="alert">
              {{ session('error') }}
          </div>
      @endif
 --}}

   
@stop 

