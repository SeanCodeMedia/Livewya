<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use Illuminate\Foundation\Auth\AuthenticatesUsers;

class logoutController extends Controller
{
 

    use AuthenticatesUsers;


    public function logout(){

             
             Auth::logout(); 


             return view (/);

    }

 
}
