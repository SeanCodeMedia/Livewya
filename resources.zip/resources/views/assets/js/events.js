// JavaScript file 
// written by Sean Peart 
// Boxing Studio Games  copy right

var Date1 = new Date();
var nextyear = Date1.getFullYear()+1;
var response = false; 

toolTip = [


		
		    ]

unavalibleDates = [

				   
				   
 ] // proper format/syntx is 01/05/2015 or 12/05/2016


// has to match index 			
imageArray = [ ];  //super defualt image in css png 1 
		   
	          $.post("js/Jsonhandler.php",{},function(tables){

	  	var dates = $.parseJSON(tables);
	     
	
		counter = 0; 
           
	 for(y = 0; y < dates.length; y++){
		                
	 			counter +=1; 
					
		 			 if (counter == 1){
						 
	 				 unavalibleDates.push(dates[y]);
		  				console.log("dates"+unavalibleDates)
						
						 
						 
		 				 } 
						 
						else if (counter == 2){
							
							toolTip.push(dates[y]);
						console.log("tooltip"+toolTip)
							 
						}
						 
					 else if (counter == 3) {
							 
						 imageArray.push(dates[y]); 
							 console.log("images"+imageArray)
							 counter = 0;
		 					 }
					          
					 
		  			 	
						
						
		  }
		  
	  	
			});	
		    
	
	
	

function MakeBookings() {
	
 setTimeout(function(){
	 
 
/*
for (var i = 0; i < unavalibleDates.length; i++){
	
 console.log (unavalibleDates[i])
	}
*/



 $("#calinder_box").datepicker({
	 
	
	 autoSize: true,
	 nextText: "Next",
	 showButtonPanel: true,
	  inline: true,
      showOtherMonths: true,
	  beforeShowDay: highlightDays,
	  onChangeMonthYear: function (){
		       
			  
			  		 
		  
		  },
	  
	 onSelect: function(date) {
		
		 
		 if ($.inArray(date, unavalibleDates) != -1){
	
			 // dates that can be clicked 
			  

			 
		  } else if ($.inArray(date, unavalibleDates) == -1) {
			  
			  // dates that cannot be clicked 


			    window.location.href = '/BookParty';

	
			  
			  }
			
			 
		
		 
		
     }
	 
	 
	 	 
	});
	
   
 function highlightDays (d){ 
	
      console.log(unavalibleDates)
    
   var dmy = (d.getMonth()+1); 
        if(d.getMonth()<9) 
            dmy="0"+dmy; 
        dmy+= "/"; 
        
        if(d.getDate()<10) dmy+="0"; 
            dmy+=d.getDate() + "/" + d.getFullYear(); 
        
        console.log(dmy+' : '+($.inArray(dmy, unavalibleDates)));
        
        if ($.inArray(dmy, unavalibleDates) != -1) {
             return [true,"event",toolTip[$.inArray(dmy, unavalibleDates)]]; 
        } else if ($.inArray(dmy, unavalibleDates > -1)){
			 return [true, "","day available"]; 
        } 
		else {
			
			console.error("Date Does not exsist")
			
			}

 }

  },2000);
};




MakeBookings();










