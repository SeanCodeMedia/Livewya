<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use DB;

use File; 

use App\backgroundImages as bg; 

class uploadImage extends Controller
{


        public function upload (Request $request)
         {  


         $this->validate($request,[

                  'file' => 'required|mimes:jpeg,png',
                 // 'file' => 'dimensions:min_width=1920,min_height=1078'
         ]);
            
          if ($request->hasFile('file')){

          	   $file = $request->file("file"); 

               $file->move('uploads/promotional',$file->getClientOriginalName());

        DB::insert('insert into PromoImages (images) values (?)', [ 'uploads/promotional/'.$file->getClientOriginalName()]);


     

         return redirect()->back()->with('message', 'Image uploaded successfully');

          

         } 
}



public function delete (Request $request){  

        $id = $request->input('ImageID'); 

        $name = $request->input("ImageName");

         $image_path = $name; 
         
        File::delete($image_path);
         
        DB::table('PromoImages')->where('id', '=', $id)->delete();


      return redirect()->back()->with('successMessage', 'Image deleted successfully');

 }


public function Deletebackground (Request $request){  

        $id = $request->input('BackgroundID'); 

        $name = $request->input("BackgroundName");

        $image_path = $name; 
         
        File::delete($image_path);
         
        DB::table('BackgroundImages')->where('id', '=', $id)->delete();


      return redirect()->back()->with('successMessage2', 'Image deleted successfully');

 }

public function uploadBackgroundImage (Request $request) {



         $this->validate($request,[

                  'file' => 'required|mimes:jpeg,png',
         ]);
            
          if ($request->hasFile('file')){

               $file = $request->file("file"); 

               $file->move('uploads/BackgroundImages',$file->getClientOriginalName());

 DB::insert('insert into BackgroundImages (imagesName) values (?)', [ 'uploads/BackgroundImages/'.$file->getClientOriginalName()]);


     

         return redirect()->back()->with('message2', 'Image uploaded successfully');

}


}



public function UploadGallery(Request $request){


   $this->validate($request,[

                  'file' => 'required|mimes:jpeg,png',
                 // 'file' => 'dimensions:min_width=1920,min_height=1078'
         ]);
            
          if ($request->hasFile('file')){

               $file = $request->file("file"); 

               $file->move('uploads/Gallery',$file->getClientOriginalName());

        DB::insert('insert into gallery (image) values (?)', [ 'uploads/Gallery/'.$file->getClientOriginalName()]);


         return redirect()->back()->with('message', 'Image uploaded successfully');

}
 

}


public function DeleteGallery (Request $request){  

        $id = $request->input('photoID'); 

        $name = $request->input("photoName");

        $image_path = $name; 
         
        File::delete($image_path);
         
        DB::table('gallery')->where('id', '=', $id)->delete();


      return redirect()->back()->with('successMessage3', 'Image deleted successfully');

 }



public function GetImages (Request $request){

     $background = bg::all();

    $ImagesArray = array();

 
  foreach ($background as $images) {

    array_push($ImagesArray,$images->imagesName);
   
   }

     return json_encode($ImagesArray);

}

// should I make another controller ? 

public function uploadVideo(Request $request){

   $this->validate($request,[

                  'url' => 'required|URL',
                
         ]);


     $url = $request->input("url");


     DB::table('video')->insert(["url" => $url]); 


        return redirect()->back()->with('successMessage3', 'Video uploaded successfully');



}


public function DeleteVideo (Request $request){  

        $id = $request->input('VideoID'); 


        DB::table('video')->where('id', '=', $id)->delete();


      return redirect()->back()->with('successMessage3', 'Image deleted successfully');

 }

}