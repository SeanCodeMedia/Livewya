<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use App\Http\Requests;
use Auth; 
use Illuminate\Support\Facades\DB;

use App\autoPlay;
use App\DJpromoImages as promoImages; 
use App\backgroundImages as bg; 
use App\gallery as gallery;
use App\video as video; 



class AdminController extends Controller
{
    /*
               only admin can access the dashboard 
               we check if user have permssion from DB; 
       */
 

   public function __construct()
    {
           
        $this->middleware('auth');
    }

      public function show(){



            if(Auth::user()->admin == 0) {
                         
                       if(Auth::check() == true ){

                       	  return redirect('/home');

                       } 

                 } 
                 else if (Auth::user()->admin == 1) {

                           $images = promoImages::all();

                           $background = bg::all();

                           $gallery = gallery::all();

                           $video = video::all(); 


                       return view("admin",compact('images','background','gallery','video'));
                 }
      	 
      }



    public function autoDJ() {
         
       $autoPlay = autoPlay::all();


   foreach ($autoPlay as $auto)         
           $state = $auto->autoPlay;


            return json_encode($state);
        
         }
        


  public function UpdateAutoPlay(Request $request){
          
           $data = $request->input("state");
      
           $query = DB::update('update autoMusic set autoPlay = ? where id = 1', [$data]);

  }

       
     }


